const { $, $$, browser, expect } = require('@wdio/globals');
const Login = require('../pageobjects/login.page');
const Inventory = require('../pageobjects/inventory.page');

describe('Login', () => {
  beforeEach(async () => {
    await Login.open();
  });

  it('TC1: valid login', async () => {
    await Login.login('standard_user', 'secret_sauce');
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  it('TC2: invalid password shows error', async () => {
    await Login.login('standard_user', 'wrong_password');
    await expect(Login.error).toBeDisplayed();
    await expect(Login.error).toHaveTextContaining(
      'Epic sadface: Username and password do not match any user in this service'
    );
  });

  it('TC3: invalid login shows error', async () => {
    await Login.login('standarD_user', 'secret_sauce');
    await expect(Login.error).toBeDisplayed();
    await expect(Login.error).toHaveTextContaining(
      'Epic sadface: Username and password do not match any user in this service'
    );
  });
});