const { $, $$, browser, expect } = require('@wdio/globals');
const Login = require('../pageobjects/login.page');
const Inventory = require('../pageobjects/inventory.page');

describe('Footer links', () => {
  before(async () => {
    await Login.open();
    await Login.login('standard_user', 'secret_sauce');
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  async function clickAndVerify(selector, expectedPart) {
    const link = await $(selector);
    await link.scrollIntoView();
    await link.click();
    await browser.switchWindow(expectedPart); 
    await expect(browser).toHaveUrlContaining(expectedPart);
    await browser.closeWindow();
    await browser.switchWindow('saucedemo.com'); 
  }

  it('Twitter',  async () => { await clickAndVerify('.social_twitter',  'x.com'); });
  it('Facebook', async () => { await clickAndVerify('.social_facebook', 'facebook.com'); });
  it('LinkedIn', async () => { await clickAndVerify('.social_linkedin', 'linkedin.com'); });
});