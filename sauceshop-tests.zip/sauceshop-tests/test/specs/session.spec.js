const { $, $$, browser, expect } = require('@wdio/globals');
const Login = require('../pageobjects/login.page');
const Inventory = require('../pageobjects/inventory.page');
const Cart = require('../pageobjects/cart.page');

describe('Session / Logout & Cart', () => {
  beforeEach(async () => {
    await Login.open();
    await Login.login('standard_user', 'secret_sauce');
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  it('TC4: logout from inventory', async () => {
    await Inventory.logoutFromMenu();
    await expect(browser).toHaveUrlContaining('/');
    await expect(Login.inputUsername).toBeDisplayed();
    await expect(Login.inputPassword).toBeDisplayed();
  });

  it('TC5: cart is preserved after logout/login (backpack example)', async () => {
    await Inventory.addBackpackToCart();
    await Inventory.logoutFromMenu();

    // login again
    await Login.login('standard_user', 'secret_sauce');
    await Inventory.openCart();

    const item = await $('//div[@class="inventory_item_name" or contains(@class,"inventory_item_name") and text()="Sauce Labs Backpack"]');
    await expect(item).toBeDisplayed(); 
  });
});