const { $, $$, browser, expect } = require('@wdio/globals');
const Login = require('../pageobjects/login.page');
const Inventory = require('../pageobjects/inventory.page');
const { parsePrice, getTexts } = require('../utils/sort-helpers');

describe('Sorting on inventory', () => {
  before(async () => {
    await Login.open();
    await Login.login('standard_user', 'secret_sauce');
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  it('sort by Name (A to Z)', async () => {
    await Inventory.sortSelect.selectByVisibleText('Name (A to Z)');
    const names = await getTexts(Inventory.productNames);
    const sorted = [...names].sort((a,b) => a.localeCompare(b));
    expect(names).toEqual(sorted);
  });

  it('sort by Name (Z to A)', async () => {
    await Inventory.sortSelect.selectByVisibleText('Name (Z to A)');
    const names = await getTexts(Inventory.productNames);
    const sorted = [...names].sort((a,b) => b.localeCompare(a));
    expect(names).toEqual(sorted);
  });

  it('sort by Price (low to high)', async () => {
    await Inventory.sortSelect.selectByVisibleText('Price (low to high)');
    const pricesText = await getTexts(Inventory.productPrices);
    const prices = pricesText.map(parsePrice);
    const sorted = [...prices].sort((a,b) => a - b);
    expect(prices).toEqual(sorted);
  });

  it('sort by Price (high to low)', async () => {
    await Inventory.sortSelect.selectByVisibleText('Price (high to low)');
    const pricesText = await getTexts(Inventory.productPrices);
    const prices = pricesText.map(parsePrice);
    const sorted = [...prices].sort((a,b) => b - a);
    expect(prices).toEqual(sorted);
  });
});