const { $, $$, browser, expect } = require('@wdio/globals');
const Login = require('../pageobjects/login.page');
const Inventory = require('../pageobjects/inventory.page');
const Cart = require('../pageobjects/cart.page');
const Checkout = require('../pageobjects/checkout.page');

describe('Checkout flow', () => {
  beforeEach(async () => {
    await Login.open();
    await Login.login('standard_user', 'secret_sauce');
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  it('TC8: valid checkout', async () => {
    await Inventory.addBackpackToCart();
    await Inventory.openCart();

    await Cart.goToCheckout();
    await Checkout.fillStepOne({ first: 'John', last: 'Doe', zip: '12345' });

    await Checkout.finish.click();
    await expect(Checkout.thankYouH2).toBeDisplayed();

    await Checkout.backHome.click();
    await expect(browser).toHaveUrlContaining('/inventory.html');
  });

  
  it.skip('TC9: checkout without products (to finalize after UX clarification)', async () => {
    await Inventory.openCart();
   
  });
});