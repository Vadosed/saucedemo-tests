const { $ } = require('@wdio/globals')
const Page = require('./page');

class CheckoutPage {
  // step one
  get firstName() { return $('#first-name'); }
  get lastName()  { return $('#last-name'); }
  get postal()    { return $('#postal-code'); }
  get continue()  { return $('#continue'); }

  // step two
  get finish()    { return $('#finish'); }

  // complete
  get thankYouH2() { return $('h2=Thank you for your order!'); }
  get backHome()   { return $('#back-to-products'); }

  async fillStepOne({ first, last, zip }) {
    await this.firstName.setValue(first);
    await this.lastName.setValue(last);
    await this.postal.setValue(zip);
    await this.continue.click();
  }
}
module.exports = new CheckoutPage();