const { $ } = require('@wdio/globals')
const Page = require('./page');

class InventoryPage {

  get addBackpack()   { return $('#add-to-cart-sauce-labs-backpack'); }
  get burger()        { return $('#react-burger-menu-btn'); }
  get logout()        { return $('#logout_sidebar_link'); }
  get cartLink()      { return $('[data-test="shopping-cart-link"]'); }
  get sortSelect()    { return $('[data-test="product-sort-container"]'); }


  get productNames()  { return $$('div.inventory_item_name'); }
  get productPrices() { return $$('div.inventory_item_price'); }

  async open() {
    await browser.url('/inventory.html');
  }

  async addBackpackToCart() {
    await this.addBackpack.waitForClickable();
    await this.addBackpack.click();
  }

  async openCart() {
    await this.cartLink.click();
  }

  async logoutFromMenu() {
    await this.burger.click();
    await this.logout.waitForClickable();
    await this.logout.click();
  }
}
module.exports = new InventoryPage();