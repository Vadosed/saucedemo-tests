const { $ } = require('@wdio/globals')
const Page = require('./page');

function parsePrice(text) {
  return parseFloat(text.replace('$', ''));
}

async function getTexts(elems) {
  const arr = [];
  for (const el of elems) arr.push(await el.getText());
  return arr;
}

module.exports = { parsePrice, getTexts };